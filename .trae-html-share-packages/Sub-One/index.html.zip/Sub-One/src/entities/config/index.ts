﻿export * from './model/useConfig';
