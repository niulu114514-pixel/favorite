// Simplified Chinese dashboard catalog. Generated from the English source and reviewed for product terminology.
const I18N_ZH = {
  "auth": {
    "brand": "第二大脑",
    "subtitle": "输入访问令牌，连接你的个人记忆空间。它就是你设置第二大脑时选择的密码。",
    "tokenPlaceholder": "访问令牌（设置时使用的密码）",
    "connect": "连接",
    "connecting": "连接中......",
    "connectingEllipsis": "连接中......",
    "fillBoth": "请同时填写这两个字段。",
    "invalidToken": "无效令牌",
    "accountSuspended": "你的账户被暂停了。请找团队管理员帮你恢复账户。",
    "accountRemoved": "您的账户已被从本团队中移除。",
    "couldNotConnect": "无法连接。",
    "serverError": "服务器错误：{status}",
    "haveInvite": "我收到了团队邀请",
    "inviteHide": "收起",
    "inviteStep1": "保持上面地址原样——那已经是这个团队的地第二大脑了。",
    "inviteStep2": "将管理员发给你的一次性令牌粘贴到上方的栏中。",
    "inviteStep3": "点击连接。你拍摄的每一件作品都会保持个人化，直到你与团队分享。",
    "sessionExpired": "您的访问令牌已不再有效。请用当前令牌重新登录。"
  },
  "nav": {
    "home": "家",
    "memories": "回忆",
    "projects": "项目",
    "team": "队",
    "refresh": "刷新",
    "settings": "设定",
    "statusEmpty": "始终记得",
    "statusCount": {
      "one": "{n}存储器",
      "other": "{n}存储的记忆"
    },
    "vectorizeFilterDegraded": "工作区过滤不可用 — 结果会在所有层级进行排名"
  },
  "home": {
    "greetingDefault": "你好",
    "greetingStillUp": "还没睡",
    "greetingMorning": "早上好",
    "greetingAfternoon": "下午好",
    "greetingEvening": "晚上好",
    "greetingLate": "夜深了",
    "placeholder": "问，或者告诉我一些值得记住的事情",
    "modeTitle": "在询问和记忆之间切换",
    "willSearch": "将搜索",
    "layerAuto": "违约",
    "layerPersonal": "个人",
    "layerShared": "共享",
    "willRemember": "将记住",
    "hintHtml": "在任意位置添加 <span class=\"hashtag\">#标签</span> 即可归档",
    "sendLabel": "发送",
    "subMemory": {
      "one": "{n}记忆",
      "other": "{n}回忆"
    },
    "subThisWeek": "{n}本周",
    "topicsLabel": "询问",
    "askAbout": "我决定了什么{tag}？",
    "receiptAlreadyKept": "已经被保留了",
    "receiptAlreadyKeptNote": "你脑子里已经有非常相似的东西了，所以这部分被跳过了。",
    "receiptCouldNotSave": "无法拯救",
    "receiptCouldNotSaveNote": "没有丢失任何东西——文字还在盒子里。再试一次。",
    "receiptStored": "储存在大脑中",
    "receiptMerged": "合并到已有的内存中",
    "receiptMergedNote": "你之前写过这件事，所以现在两者成了回忆。",
    "receiptReplaced": "替换了过时的记忆",
    "receiptReplacedNote": "旧版本已经消失;这个版本取代了它。",
    "receiptConflict": "被储存，而更古老的东西现在却不同意",
    "receiptConflictNote": "你的大脑注意到这与早期记忆冲突，并保留了较新的记忆。",
    "receiptDraft": "以草稿形式存储",
    "receiptDraftNote": "这会与你已确认的记忆冲突，因此保持不确认，而不是覆盖。",
    "receiptSimilar": "存放，靠近你已有的东西",
    "receiptSimilarNote": "标记为可能的重复品，方便你以后比较。",
    "receiptFiledUnder": "分类",
    "firstRunEyebrow": "开始",
    "firstRunHero": "你的第二大脑是空的。这里是万物居住的地方。",
    "firstRunStep1": "上面的框子同时做了两件事：写一个陈述并保存，提出问题并得到回答。它在你发送之前告诉你它即将做哪一个。",
    "firstRunStep2": "“记忆”包含你保存的所有内容，可按日期查看，也可通过关系图浏览。",
    "firstRunStep3": "在设置中连接 Claude、ChatGPT、Cursor、电子邮件和日历，让它们读取同一个记忆空间并向其中添加内容。",
    "autoPersonalYours": "自动→个人（你的设定）",
    "autoPersonalOrg": "自动→个人（组织默认）",
    "autoSharedYours": "自动→共享（你的设置）",
    "autoSharedOrg": "自动→共享（组织默认）",
    "pinnedPersonal": "这次是个人的",
    "pinnedShared": "这个奖是全队的"
  },
  "board": {
    "tileOpenMemories": "开放的回忆",
    "tileOpenGraph": "打开图表",
    "tileGoRecalled": "前往最被召回者名单",
    "tileOpenContradictions": "公开解决了矛盾",
    "tileMemories": "回忆",
    "tileWeek": "{n}这周存档",
    "tileConnections": "记忆之间的联系\n回忆回",
    "tileRecalls": "次",
    "tileRecallsDelta": "所有连接工具",
    "tileContradictions": "矛盾得以解决",
    "tileContradictionsDelta": "每次都保留着新的信念",
    "decideTitle": "需要一个决定",
    "decideSub": "这里没有任何内容可以被召回，除非你裁定",
    "topicsTitle": "内容简介",
    "topicsSub": "最常用标签",
    "rereadSub": "古老、重要，且与你现在正在做的事情相关",
    "loopsTitle": "开放环",
    "loopsSub": "你说过要做的事",
    "saved": "被拯救",
    "growthTitle": "记忆随时间流逝",
    "growthSubDay": "每天节省",
    "growthSubBrief": "过去14天",
    "chartNeedsUpdate": "源和更长范围需要随该仪表盘附带的 Worker 更新。",
    "rangeLabel": "射击场",
    "range30": "30天",
    "range90": "90天",
    "range365": "1年",
    "seriesAll": "所有资料来源",
    "seriesOther": "其他",
    "chartShowTable": "作为表格展示",
    "chartHideTable": "隐藏表",
    "chartColDay": "日",
    "chartColWeek": "周",
    "chartColTotal": "总计",
    "chartCaptionDay": "每天保存的记忆数，原始计数，按来源划分",
    "chartCaptionAvg": "按来源划分的每日保存记忆，7天中心平均",
    "chartCaptionWeek": "按来源划分的每周保存回忆",
    "chartSubDay": "按他们来自的地方每天节省",
    "chartSubAvg": "按他们来自的地方，平均每天节省7天",
    "chartSubWeek": "每周节省，取决于他们的来历",
    "chartTipPerDay": "一天",
    "chartTipMemories": {
      "one": "{n}记忆",
      "other": "{n}回忆"
    },
    "chartAriaLabel": "过去 {days} 天内每{unit}保存 {n} 条，按来源堆叠，共 {total} 条",
    "chartUnitDay": "日",
    "chartUnitWeek": "周",
    "graphTitle": "它的联系方式",
    "graphSub": "主题群，最强链接先行",
    "openGraph": "开放图",
    "graphLegend": "显示 {shown}/{total} 条记忆 · {topics} 个主题\n节点大小表示关联程度",
    "graphSize": "重要性之后",
    "graphShowing": "正在显示 {tag} · {n} 条记忆",
    "graphShowingAll": "显示所有主题",
    "recalledTitle": "你总是回到的",
    "recalledSub": "史上最被回忆的人物",
    "recalls": {
      "one": "{n}回忆",
      "other": "{n}召回"
    },
    "nightTitle": "昨晚",
    "nightSub": "维护任务于 {time} 运行\n已推断关联",
    "nightLinks": "链接",
    "nightInsights": "见解",
    "nightDigests": "摘要",
    "nightClaims": "被标记为老化的说法",
    "linksTitle": "链接类型",
    "linksSub": {
      "one": "{n}联系",
      "other": "{n}连接"
    },
    "edge": {
      "relates_to": "相关内容",
      "supersedes": "替代者",
      "caused_by": "原因",
      "decided": "决定",
      "about_person": "关于人物",
      "part_of_project": "项目的一部分",
      "follows": "后续",
      "drawn_from": "选自"
    },
    "railVersion": "工人{v}",
    "railIndexOk": "指数健康",
    "railIndexDegraded": "索引需要关注",
    "railHost": "与{host}相关",
    "upkeepTitle": "维护",
    "upkeepSub": "家务是大脑无法替你决定的",
    "sourcesTitle": "资料来源",
    "sourcesSub": "自己填满大脑",
    "manage": "管理",
    "synced": "同步{when}",
    "notConnected": "没有关联",
    "capsuleTitle": "提示胶囊",
    "capsuleSub": "每个工具最先加载的东西",
    "slotIdentity": "身份",
    "slotPreferences": "偏好",
    "slotConstraints": "约束",
    "slotPrinciples": "原则",
    "slotMemories": {
      "one": "{n}记忆",
      "other": "{n}回忆"
    },
    "slotEmpty": "空无一人",
    "capsuleAdd": "添加一个",
    "capsuleAddHint": "保存一个带标签的内存 {tag} 来填补该槽位",
    "topicBrowse": "查看标记为 {tag} 的记忆"
  },
  "recall": {
    "eyebrow": "召回",
    "hero": "问我你藏着的什么——我会找到，用你的话回答。",
    "placeholder": "问问你的大脑......",
    "backHome": "返回首页",
    "allTags": "所有标签",
    "sugWorkingOn": "我在做什么？",
    "sugDecidedRecently": "我最近决定了什么？",
    "sugTasks": "展示我的任务",
    "sugGoals": "我的目标是什么？",
    "sugIdeas": "我有什么想法？",
    "sugLastWeek": "上周",
    "sugLastWeekQuery": "上周发生了什么？",
    "sugThisMonth": "本月",
    "sugThisMonthQuery": "这个月我决定了什么？",
    "empty": "我找不到符合这个的词。试试不同的词，或者浏览记忆。",
    "error": "出了点问题。检查一下你的连接，再试一次。",
    "youAsked": "你问过",
    "sourcesFound": {
      "one": "找到 · {n} 来源",
      "other": "找到 · {n} 来源"
    },
    "citeTitle": "显示来源 {n}",
    "citedAs": "在答案中引用为 [{n}]",
    "relatedHop": {
      "one": "相关 · {n} 跳",
      "other": "相关 · {n} 跳数"
    }
  },
  "memories": {
    "allTime": "所有时间",
    "today": "今天",
    "yesterday": "昨天",
    "last7": "最近7天",
    "last30": "最近30天",
    "thisMonth": "本月",
    "weekOf": "{date} 那一周",
    "legend": "按项目和标签分组 · 点击记忆以打开",
    "viewAria": "如何查看你的记忆",
    "viewList": "列表",
    "viewListTitle": "按时间",
    "viewGraph": "图表",
    "viewGraphTitle": "按连接",
    "loading": "正在加载记忆…",
    "loadingShort": "正在加载…",
    "loadFailed": "无法加载记忆。",
    "empty": "暂无记忆。使用记忆功能保存你的第一条记忆。",
    "vecPendingTitle": "正在向量化…（刚捕获）",
    "vecOffTitle": "未向量化 — 不会出现在回忆中",
    "vecNotIndexed": "未建立索引",
    "append": "附加",
    "edit": "编辑",
    "forget": "忘记",
    "forgetThis": "忘记这条记忆",
    "moreActions": "更多操作",
    "allLayers": "所有层",
    "personalLayer": "个人",
    "sharedLayer": "共享",
    "sharedChip": "已共享",
    "sharedTitle": "对整个团队可见 — 溢出菜单可再次设为私密",
    "shareWithTeam": "与团队共享",
    "makePrivate": "设为私密",
    "authorLabel": "作者：{name}",
    "timelineLabel": "历史",
    "confirmTitle": "忘记这条记忆？",
    "confirmBody": "此操作无法撤销。记忆将从你的大脑中移除。",
    "cancel": "取消",
    "appendTitle": "添加更新",
    "appendPlaceholder": "有什么变化或新增内容？",
    "appendSave": "更新",
    "saving": "正在保存…",
    "appendFailed": "附加失败：{message}",
    "editTitle": "编辑记忆",
    "editPlaceholder": "编辑你的记忆…",
    "editHintHtml": "点击标签以移除。使用 <span style=\"font-style: italic\">#hashtags</span> 在文本中添加标签。",
    "editSave": "保存",
    "editFailed": "编辑失败：{message}",
    "removeTag": "移除标签 {tag}",
    "viewTitle": "记忆",
    "forgetting": "正在忘记…",
    "forgetFailed": "无法忘记：{message}",
    "metaCaptured": "捕获 {relative}",
    "metaEdited": "编辑 {relative}",
    "brainLabel": "你的大脑所知道的",
    "importance": "重要性",
    "importanceTitle": "重要性 {n}（满分5）",
    "kind": "类型",
    "status": "状态",
    "lifespan": "生命周期",
    "recalled": "已回忆",
    "recalledTimes": {
      "one": "{n} 次",
      "other": "{n} 次"
    },
    "kindFact": "事实",
    "kindEvent": "事件",
    "statusTrusted": "可信",
    "statusUnconfirmed": "未确认",
    "statusSuperseded": "已被替代",
    "volDurable": "耐久",
    "volDurableGloss": "预计不会改变。",
    "volCurrent": "当前",
    "volCurrentGloss": "目前为真 — 助手在依赖之前会验证。",
    "volShortLived": "短期",
    "volShortLivedGloss": "这只是短暂的——助理们认为它可能有些陈旧。",
    "disagreed": {
      "one": "有些新的东西{n}不同意。",
      "other": "有 {n} 条较新的记忆与此不一致。"
    },
    "notIndexedYet": "尚未被索引——回忆找不到这段记忆。",
    "related": "相关",
    "close": "关闭",
    "selectMemory": "选择记忆：{title}",
    "youLinked": "由你关联",
    "systemLinked": "系统联结",
    "autoLinked": "自动链接",
    "removeLink": "删除链接",
    "removeLinkConfirm": "移除这个链接？记忆会保留;只有连接被删除。",
    "untitled": "无题回忆",
    "evCreated": "被捕",
    "evUpdated": "编辑",
    "evAppended": "新增",
    "evDeleted": "已删除",
    "evStatusChanged": "状态变更",
    "evShared": "与团队共享",
    "evUnshared": "再次变得个人化",
    "authorLockedTitle": "只有作者可以更改共享记忆",
    "authorLocked": "由{name}分享——只有他们可以编辑或删除",
    "allAuthors": "所有作者",
    "authorFilterTitle": "只展示一个人分享的内容",
    "authorYou": "你"
  },
  "graph": {
    "empty": "还没有连接——连接记忆，或者让它们随着你添加更多自动连接。",
    "loadFailed": "无法加载图表。",
    "zoomOut": "缩小",
    "zoomIn": "放大",
    "fit": "适合观看",
    "relayout": "重新铺设",
    "layerTitle": "显示一层或两层",
    "layerAll": "所有层",
    "layerPersonal": "个人",
    "layerShared": "共享",
    "sharedLegend": "与团队共享",
    "byAuthor": "由{name}"
  },
  "menu": {
    "title": "你的大脑",
    "groupUpkeep": "维护",
    "groupData": "数据",
    "groupConnections": "连接",
    "groupThisApp": "这个应用",
    "backupJson": "备份为JSON",
    "exportMarkdown": "导出为Markdown格式",
    "restore": "从备份恢复",
    "integrations": "集成",
    "appearance": "外观",
    "themeLight": "浅色",
    "themeDark": "深色",
    "themeAuto": "自动",
    "themeMatchSystem": "跟随系统",
    "aboutAria": "关于第二大脑",
    "about": "关于",
    "createdBy": "创作者",
    "maintainers": "维护者",
    "disconnect": "断开连接",
    "exportFailed": "导出失败：{message}",
    "exportMdTitle": "# 第二大脑导出",
    "exportMdExported": "导出：{date}",
    "exportMdMemory": "## 记忆{n}",
    "exportMdDate": "**日期：** {date}",
    "exportMdTags": "**标签：** {tags}",
    "exportMdSource": "**来源：** {source}",
    "exportMdRelationships": "## 关系"
  },
  "upkeep": {
    "working": "工作中......",
    "done": "完成",
    "requestFailed": "请求失败",
    "digestLabel": "准备压缩",
    "digestNote": "原创从不被删除——摘要会添加摘要，并将原创的回忆排名降低，以避免结果被挤压。",
    "digestEntries": {
      "one": "{n}条目",
      "other": "{n}条"
    },
    "digestAction": "摘要→",
    "digestMore": "{n}更多 ›",
    "digestFailed": "无法制作摘要",
    "digestPreserved": {
      "one": "{n}原始内存保存完好且仍可搜索",
      "other": "{n}原始记忆保存并仍可检索"
    },
    "vectorizeLabel": "未建立索引",
    "vectorizeNote": {
      "one": "{n}记忆未能嵌入，回忆中也不会出现。",
      "other": "{n}记忆未能嵌入，回忆中也不会出现。"
    },
    "vectorizeAction": "现在就向量化 →",
    "vectorizeDone": "完成 — {n}重新索引",
    "classifyLabel": "非机密",
    "classifyNote": {
      "one": "{n}记忆尚未有类型或状态标签（在分类出现前就被捕获）。",
      "other": "{n}记忆尚未有类型或状态标签（在分类出现前就被捕获）。"
    },
    "classifyAction": "立即分类→",
    "classifyDone": "完成 — {n}机密",
    "restoreLabel": "恢复",
    "restoreProgress": "正在从 {filename} 恢复……",
    "restoreOf": "已处理 {done} / {total}",
    "restoreTryAgain": "再试一次→",
    "restoreFailureTail": "您的备份文件未被修改，可以安全重试——已恢复的内容会被跳过，而非重复。",
    "restoreInvalidJson": "{filename} JSON不有效。",
    "restoreNotBackup": "{filename}看起来不像第二大脑备份——没有条目列表。使用“备份为JSON”创建的文件。",
    "restoreStopped": "恢复工作中途停止了。",
    "restoreSummaryRestored": "{n}修复",
    "restoreSummaryConnections": "{n}连接",
    "restoreSummaryPresent": "{n}已经存在了",
    "restoreFailNote": "{n}项无法恢复——通常是手工编辑的行;其余的则不受影响。",
    "restoreNeedsIndex": "恢复的记忆在被索引之前无法搜索。",
    "restoreMakeSearchable": "让可搜索→",
    "restoreIndexing": "索引......",
    "restoreIndexingProgress": "正在建立索引……已完成 {done} 条，还剩 {remaining} 条",
    "restoreIndexingDoneOnly": "正在建立索引……已完成 {done} 条",
    "restoreQuotaLeft": "{n} — 每日AI极限已达，明天再试",
    "restoreAllSearchable": "所有恢复的记忆都可以搜索",
    "restoreIndexFailed": "失败 — 点击重试",
    "importStalled": "服务器没有推进导入光标——Worker是最新的吗？",
    "vectorizeBannerTitle": "语义搜索已被禁用。未找到Vectorize索引“{name}”。",
    "vectorizeBannerHowToFix": "如何修复",
    "vectorizeBannerRunOnce": "在终端里运行一次：",
    "vectorizeBannerGui": "或者在 Cloudflare 仪表盘（我的个人资料，API 令牌）中赋予 Workers Builds API 代币账户级别的 Vectorize 编辑权限，然后重新部署，这样构建会自动创建索引。"
  },
  "integrations": {
    "intro": "连接工具，而你的上下文已经存在。同步内容保持最新，并在回忆中像其他记忆一样浮现。",
    "loading": "加载中......",
    "backSettings": "返回设置",
    "backList": "回到集成",
    "loadFailed": "无法加载集成。",
    "none": "没有可用的集成。",
    "adminsOnly": "只有工作区管理员可以更改连接。",
    "emptyCategory": "这里还没有消息。",
    "categoryKnowledge": "知识",
    "categoryCalendars": "日历",
    "categoryEmail": "电子邮件",
    "categoryOther": "其他",
    "summaryConnected": {
      "one": "{n}连接",
      "other": "{n}连接"
    },
    "notConnected": "无关联",
    "connected": "连接",
    "pasteSecret": "粘贴你的秘密",
    "emailPlaceholder": "you@example.com",
    "emailAria": "电子邮件地址",
    "appPassword": "应用密码",
    "appPasswordAria": "应用密码",
    "notionPlaceholder": "整合秘密（ntn_...）",
    "urlPlaceholder": "https://…",
    "notionHint": "在 <a href=\"https://app.notion.com/developers/connections\" target=\"_blank\" rel=\"noopener\">Notion 开发者连接页面</a>创建内部<strong>连接</strong>（不是个人访问令牌），将需要同步的页面共享给该连接，然后粘贴连接密钥。",
    "needEmailPw": "输入您的邮箱和应用密码。",
    "needSecret": "先把你的秘密粘贴上去。",
    "mirrorLayerTitle": "同步记忆落在哪里",
    "couldNotConnectShort": "无法连接",
    "layerChangeFailedShort": "无法更改图层",
    "syncNow": "现在同步",
    "syncing": "同步中......",
    "syncingProgress": "同步中......目前{n} {noun}",
    "synced": {
      "one": "{n}同步",
      "other": "{n}同步"
    },
    "syncFailed": "同步失败",
    "lastSyncFailed": "最后一次同步失败：{error}",
    "countSynced": {
      "one": "{n} {noun}同步",
      "other": "{n} {noun}同步"
    },
    "lastSync": "最后同步：{when}",
    "never": "从来没有",
    "disconnectConfirm": "断开{name}？它会停止同步。",
    "purgeConfirm": {
      "one": "也删除{n}同步{noun}",
      "other": "也删除{n}同步{noun}"
    },
    "disconnecting": "断开连接......",
    "disconnectFailed": "断开失败",
    "nounEvent": {
      "one": "事件",
      "other": "事件"
    },
    "nounEmail": {
      "one": "邮箱",
      "other": "邮件"
    },
    "nounItem": {
      "one": "项",
      "other": "项目"
    },
    "nounMemory": {
      "one": "记忆",
      "other": "回忆"
    },
    "connect": {
      "calendar-google": {
        "label": "粘贴你的谷歌日历秘密iCal URL",
        "placeholder": "https://calendar.google.com/calendar/ical/…/basic.ics",
        "hint": "在谷歌日历（网页版）：设置日历→→<b>整合日历</b>中→复制<b>“iCal格式的秘密地址”</b>。保持私密——任何拥有该地址的人都可以阅读日历。"
      },
      "calendar-outlook": {
        "label": "粘贴你发布的 Outlook 发布的 ICS URL",
        "placeholder": "https://outlook.live.com/owa/calendar/…/calendar.ics",
        "hint": "Outlook.com 中：设置 → 日历 → <b> 共享日历</b> → 发布日历→发布，然后复制<b>ICS</b>链接。（工作/学校账户可能禁用发布功能。）"
      },
      "calendar-icloud": {
        "label": "粘贴你的iCloud共享日历网址",
        "placeholder": "webcal://p…-caldav.icloud.com/published/…",
        "hint": "在“日历”（Mac 或 iCloud.com）中：右键单击日历 → <b>共享日历</b> → 启用 <b>公共日历</b> → 复制 webcal 链接。"
      },
      "email-gmail": {
        "label": "连接您的Gmail收件箱",
        "placeholder": "16 字符应用密码",
        "hint": "在您的 Google 帐号 → 安全性 → 两步验证 → <b>应用专用密码</b>，为邮件创建一个，然后输入您的 Gmail 地址和该密码。（需要启用两步验证；Gmail 设置中必须启用 IMAP。）"
      },
      "email-icloud": {
        "label": "连接您的 iCloud 收件箱",
        "placeholder": "应用专用密码",
        "hint": "在 appleid.apple.com → 登录与安全 → <b>应用专用密码</b>，生成一个，然后输入您的 iCloud 邮箱和该密码。"
      }
    },
    "connectedByLabel": "已被 {name} 连接",
    "mirrorPersonal": "来自此来源的新记忆将进入个人层",
    "mirrorShared": "来自此来源的新记忆将进入共享团队层",
    "mirrorLayerNewSyncsOnly": "仅适用于新的同步 — 已同步的记忆保持原位。",
    "connectedOn": "已连接 {when}",
    "moveHint": {
      "one": "将 {n} {noun} 已同步的内容移动到“{layer}”。",
      "other": "将 {n} {noun} 已同步的内容移动到“{layer}”。"
    },
    "moveNow": "立即移动",
    "moving": "正在移动…",
    "movingProgress": "已移动… {n} {noun} 到目前为止",
    "moveFailedShort": "移动失败",
    "moveResultMoved": {
      "one": "{n} 已移动",
      "other": "{n} 已移动"
    },
    "moveResultRefused": {
      "one": "{n} 被拒绝",
      "other": "{n} 被拒绝"
    },
    "moveResultMissing": {
      "one": "{n} 缺失",
      "other": "{n} 缺失"
    },
    "moveResultNone": "没有剩余可移动的内容",
    "moveResultFailed": {
      "one": "{n} 记忆无法移动 — 请检查连接后重试。",
      "other": "{n} 记忆无法移动 — 请检查连接后重试。"
    },
    "moveResultNeedsRepair": "尚不可搜索",
    "moveStoppedPartway": "目前已移动 {n} — 移动过程中停了。可以安全再试：已移动的内容将被跳过，不会重复。",
    "moveFailedFirstCall": "在移动任何内容之前失败。可以安全再试。",
    "moveRefusedOwner": "被拒绝 — 只有脑子主人可以移动这些记忆。",
    "moveLayerChanged": "自确认移动以来层已改变。请重新确认以继续。",
    "moveLayerChangedPartial": {
      "one": "自确认移动以来层已改变。{n} 记忆已移动到先前确认的层。请重新确认以决定下一步。",
      "other": "自确认移动以来层已改变。{n} 记忆已移动到先前确认的层。请重新确认以决定下一步。"
    },
    "moveVectorFailures": {
      "one": "{n} 记忆移动成功，但在新层中尚不可搜索 — 重新运行移动以完成修复。",
      "other": "{n} 记忆移动成功，但在新层中尚不可搜索 — 重新运行移动以完成修复。"
    },
    "confirmMoveBodyShared": {
      "one": "将 {n} {noun} 已同步的内容移动到共享团队层，在那个层中整个团队可见。",
      "other": "将已同步到共享团队层的 {n} {noun} 移动到该层，在团队中所有人都可见。"
    },
    "confirmMoveBodyPersonal": {
      "one": "将已同步到你的个人层的 {n} {noun} 移动到个人层，仅对你可见。",
      "other": "将已同步到你的个人层的 {n} {noun} 移动到个人层，仅对你可见。"
    }
  },
  "projects": {
    "title": "项目",
    "newProject": "新建项目",
    "emptyTitle": "给你的记忆一个归属",
    "emptyBody": "项目是关于某件事的记忆的命名归属：一个网站、一段旅行、一个客户。存放在项目下的记忆在搜索和图谱中保持在一起，你的 AI工具可以为你整理其中的内容。",
    "emptyStart": "在下方命名你的第一个项目。",
    "createTitle": "新建项目",
    "nameLabel": "项目名称",
    "namePlaceholder": "例如：网站重启",
    "descLabel": "描述",
    "descPlaceholder": "这个项目是关于什么的？（可选）",
    "layerLabel": "项目的存放位置",
    "slugEmpty": "给它一个简短名称。Slug 是标签和 AI 工具引用它的方式。",
    "slugInvalid": "名称中至少使用一个字母或数字。",
    "slugTaken": "已存在具有该 slug 的项目。",
    "slugPreview": "Slug：{slug}",
    "create": "创建项目",
    "creating": "创建中…",
    "createdToast": "项目 \"{name}\" 已创建",
    "createFailed": "无法创建该项目",
    "count": {
      "one": "{n}记忆",
      "other": "{n}回忆"
    },
    "countApprox": "{n} 记忆",
    "countNone": "尚无记忆",
    "archivedToggle": "已归档（{n}）",
    "loading": "项目加载中…",
    "loadFailed": "无法加载项目",
    "retry": "再试一次",
    "back": "所有项目",
    "archivedChip": "已归档",
    "memoriesTitle": "回忆",
    "memoriesEmpty": "这里尚未存储任何内容。当你记起某些内容时选择此项目，或在下方添加别名以引入你已使用的标签。",
    "memoriesShowing": "显示最新的 {n} 记忆。",
    "aliasesTitle": "别名",
    "aliasesHelp": "别名将你已使用的标签引入此项目。具有该标签的记忆会显示在这里，且不会被重写。",
    "aliasNone": "尚无别名",
    "aliasPlaceholder": "添加已有标签",
    "aliasAdd": "添加",
    "aliasRemove": "移除别名 {tag}",
    "aliasSuggestLabel": "你已使用的标签",
    "aliasSuggestTitle": "将 {tag} 添加为别名",
    "aliasInvalid": "别名必须是普通标签，例如 \"cycling\" 。保留标签如 kind: 或 project: 不能使用。",
    "aliasLimit": "一个项目最多可以有 16 个别名。",
    "aliasFailed": "无法更新别名",
    "detailsTitle": "详情",
    "save": "保存更改",
    "savedToast": "项目已更新",
    "saveFailed": "无法保存更改",
    "updateFailed": "无法更新项目",
    "digestTitle": "摘要",
    "digestHelp": "将本项目的记忆浓缩成一条摘要记忆。原始记忆将被保留。",
    "digestAction": "创建摘要",
    "capsuleSub": "连接的人工智能工具在开展本项目之前会加载哪些内容？",
    "slotCurrentState": "现状",
    "slotDecisions": "判决",
    "slotOpenQuestions": "开放式问题",
    "slotSet": "在舱内",
    "capsuleHowTo": "要填充槽位，保存一个带有规范内存标签的 capsule：project：{slug} 和 capsule-slot：current-state（或 decisions， open-questions）。",
    "manageTitle": "归档或删除",
    "archive": "档案项目",
    "restore": "修复项目",
    "archiveHelp": "归档项目会离开拣选器和每晚摘要。不会删除任何内容，你可以随时恢复。",
    "archivedToast": "项目已存档",
    "restoredToast": "项目恢复",
    "delete": "删除项目",
    "deleteTitle": "删除“{name}”？",
    "deleteBody": "记忆会被保留;只有项目分组被移除。",
    "deletedToast": "项目已删除",
    "deleteFailed": "无法删除该项目",
    "pickerNone": "无项目",
    "pickerLabel": "归档于项目",
    "filterAll": "所有项目",
    "filterLabel": "按项目筛选",
    "chipTitle": "项目：{name}"
  },
  "team": {
    "title": "队",
    "nameLabel": "队名",
    "namePlaceholderTeam": "，例如Acme工程",
    "nameSave": "保存",
    "nameSaved": "球队名称更新",
    "nameNeeded": "先给团队起个名字。",
    "nameHint": "团队里每个人都看到这个名字。",
    "membersLabel": "成员",
    "rosterCaption": "团队成员",
    "colMember": "成员",
    "colRole": "角色",
    "colCaptures": "捕获",
    "colActions": "行动",
    "lastUsed": "最后使用的{when}",
    "lastUsedNever": "从未使用过",
    "adminsOnly": "只有工作区管理员可以管理团队成员。",
    "rosterHint": "这个团队的每个人都可以。只有管理员可以添加或移除人员。",
    "yourCaptureTitle": "你的新捕获",
    "yourCaptureHint": "当你不选择图层时，捕获的去向。你仍然可以根据内存选择。",
    "roleAdmin": "行政",
    "roleMember": "成员",
    "you": "你",
    "suspendedChip": "被停职",
    "privateEntries": {
      "one": "{n}私人条文",
      "other": "{n}私人条目"
    },
    "rotateToken": "重置令牌",
    "remove": "移除",
    "removeConfirm": "移除{name}？他们{n}的私人记忆将永远删除。他们与团队共享的记忆会保留。",
    "defaultShareLabel": "捕获：",
    "suspend": "暂停",
    "restore": "恢复",
    "rotateConfirm": "为{name}发一个新的登录令牌？一旦使用了新的令牌，他们当前的引牌就无法使用。",
    "suspendConfirm": "暂停{name}？他们会立即失去访问权限。",
    "addTitle": "添加成员",
    "namePlaceholder": "名称",
    "emailPlaceholder": "电子邮件（可选）",
    "addAction": "添加成员",
    "adding": "补充......",
    "needName": "先给成员一个名字。",
    "duplicateEmail": "那个邮箱已经属于某个成员了。",
    "actionFailed": "没用。再试一次。",
    "tokenTitle": "一次性登录令牌",
    "tokenReady": "你的一次性代币准备好了。现在复制。",
    "tokenFor": "{name} 的令牌",
    "tokenWarning": "现在复制——你不会再看到它。",
    "copy": "复制",
    "copied": "已复制",
    "done": "完成",
    "orgDefaultLabel": "新捕获默认到",
    "defaultShareTitle": "当此成员未指定时，其新捕获的落点",
    "sharePersonal": "个人（私密）",
    "shareCompany": "公司（共享）",
    "shareInherit": "组织默认",
    "sharedToast": "与团队共享",
    "unsharedToast": "已移回个人",
    "undo": "撤销",
    "profileTitle": "你的显示名称",
    "profileSave": "保存名称",
    "profileSaved": "名称已更新",
    "rotateTitle": "重置此成员的令牌？",
    "suspendTitle": "暂停此成员？",
    "removeTitle": "移除此成员？",
    "restoredToast": "访问已恢复",
    "rotating": "重置中…",
    "suspending": "暂停中…",
    "removing": "移除中…",
    "myDefaultLabel": "新捕获：",
    "myDefaultSaved": "捕获默认已更新",
    "insightsLabel": "每周团队见解",
    "insightsOff": "关闭",
    "insightsOn": "开启",
    "insightsHint": "当此功能开启时，大脑每周会寻找共享记忆之间的联系，并将其发现放入每个人的回顾队列中。",
    "modeTitle": "团队模式",
    "modeLabel": "共享团队层",
    "modeHint": "开启此功能会添加一个每位团队成员都可以阅读的共享层。你的个人记忆保持私密。",
    "modeLocked": "此团队有 {n} 人，因此共享层保持开启。移除除你以外的所有人即可关闭。",
    "modeOnSaved": "团队模式开启——共享层已激活",
    "modeOffSaved": "团队模式关闭——此大脑再次为个人"
  },
  "invite": {
    "copy": "复制邀请信息",
    "copied": "邀请已复制",
    "email": "邮件邀请",
    "subject": "你的 第二大脑 团队邀请",
    "body": "嗨 {name}，\n\n你已被添加到我们的共享 第二大脑——整个团队都可以搜索的一条记忆。\n\n1. 打开 {url}\n2. 粘贴你的团队登录令牌：\n{token}\n3. 点击连接。\n\n你捕获的任何内容保持个人，除非你与团队分享。请保留——如果你在其他电脑上设置，需要再次使用。如遇停止工作，请向管理员申请重新发放。"
  },
  "brief": {
    "eyebrow": "你最近的大脑",
    "lastDays": "最近 {n} 天",
    "whereFrom": "来源",
    "activityTitle": {
      "one": "{date}：{n} 条记忆",
      "other": "{date}：{n} 条记忆"
    },
    "attentionUnindexed": "{n} 无法搜索",
    "attentionStale": "{n} 可能已过期",
    "attentionDue": "{n} 到期",
    "patternNoticed": "见解已注意",
    "confirm": "确认",
    "dismiss": "忽略",
    "confirmed": "已确认——现在可回忆",
    "dismissed": "已忽略",
    "failedRetry": "失败——重试",
    "worthRereading": "值得重读",
    "fromDate": "· 来自 {date}",
    "shapeSuffix": "· {shape}",
    "moreInsights": {
      "one": "{n} 更多见解等待 →",
      "other": "{n} 更多见解等待 →"
    },
    "moreInsightsGeneric": "更多见解正等待→"
  },
  "stale": {
    "title": "可能已经过时了",
    "intro": "这些在你写的时候是真的，并且带有一个会被遗忘的声明。更新一个以确认、添加、保持其真实性，或者忘记它。编辑、添加或保留这些标记可以清除标记，因为记忆刚刚被确认。",
    "empty": "没有什么看起来过时。",
    "loadFailed": "无法加载可能过时的内容。",
    "lastConfirmed": "最后确认{date}",
    "keep": "堡",
    "keepFailed": "无法保留这段记忆：{message}",
    "more": "{n}更多"
  },
  "loops": {
    "title": "开放环",
    "empty": "什么都没开。",
    "loadFailed": "无法加载你的开环。",
    "done": "完成",
    "notTask": "不是任务",
    "doneFailed": "无法标记为完成：{message}",
    "notTaskFailed": "无法更新此内容：{message}",
    "more": "{n}更多",
    "seeAll": "查看全部"
  },
  "due": {
    "title": "到期",
    "empty": "没有什么到期的。",
    "loadFailed": "无法加载应缴款项。",
    "due": "截止日期：{date}",
    "done": "完成",
    "notCommitment": "不是承诺",
    "snoozeTomorrow": "明天",
    "snoozeNextWeek": "下周",
    "doneFailed": "无法标记为完成：{message}",
    "clearFailed": "无法更新此内容：{message}",
    "snoozeFailed": "无法稍后提醒：{message}"
  },
  "notifications": {
    "title": "通知",
    "enable": "启用通知",
    "disable": "关闭通知",
    "enabled": "该设备已开启通知。",
    "disabledHint": "当某项东西到期时，这台设备会收到通知。",
    "contentFree": "在通知中隐藏内存内容",
    "unsupported": "推送通知不支持该浏览器。",
    "installToEnable": "安装应用以启用通知",
    "installHint": "通知需要先第二大脑安装到主屏幕。",
    "permissionDenied": "本网站的通知已被屏蔽。请在浏览器设置中允许它们。",
    "enableFailed": "无法启用通知：{message}",
    "disableFailed": "无法禁用通知：{message}"
  },
  "installGuide": {
    "title": "安装第二大脑",
    "why": "提醒一旦出现在主屏幕，第二大脑就能到达这部手机。",
    "installButton": "安装",
    "stepShareIcon": "点击分享图标",
    "stepAddToHomeScreen": "然后点击“添加到主屏幕”",
    "stepMenu": "打开菜单",
    "stepInstallAndroid": "然后点击“安装”或“添加到主屏幕”",
    "stepGeneric": "打开浏览器菜单，寻找“添加到主屏幕”或“安装应用”。",
    "thenOpen": "然后从主屏幕打开它并打开通知。",
    "nudgeText": "安装第二大脑以在这部手机上获取提醒。",
    "nudgeAction": "学习方法",
    "dismissAria": "忽略"
  },
  "patterns": {
    "title": "洞察",
    "intro": "你的大脑通过连接两个相隔几个月的记忆来绘制这些。确认其中一个，使其成为可信且可回忆的事实;关闭以丢弃它。这里没有任何内容可以搜索，直到你确认它。",
    "selectAll": "全部选择",
    "nSelected": "{n}选",
    "confirmN": "确认{n}",
    "dismissN": "解雇{n}",
    "loadFailed": "无法加载你的见解。",
    "emptyIntro": "没有什么在等你。",
    "emptyBody": "你大脑中引出的每一个洞察都被裁定。",
    "noticedWhen": "注意到了{date}",
    "sourceGone": "这段记忆已经不在你的脑海里了。",
    "more": "{n}更多 ›",
    "failed": "失败",
    "upkeepNote": {
      "one": "{n}洞察正在等待决定。在确认之前，它会被排除在召回之外。",
      "other": "{n}洞察正在等待决定。他们在确认前不会被召回。"
    },
    "reviewOne": "→",
    "reviewAll": "全部评论→",
    "shapes": {
      "contradiction": "矛盾",
      "throughline": "主线",
      "connection": "联系"
    }
  },
  "download": {
    "mac": "Mac 版下载",
    "windows": "Windows 版下载",
    "generic": "下载应用",
    "withTag": "{label}（{tag}）"
  },
  "common": {
    "justNow": "刚才",
    "minutesAgo": "{n}m 前",
    "hoursAgo": "{n}h 前",
    "daysAgo": "{n} 天前",
    "weeksAgo": "{n}w 前",
    "monthsAgo": "{n}mo 之前",
    "yearsAgo": "{n}y 前",
    "sourceManual": "手册",
    "sourceCli": "CLI",
    "sourceEmail": "邮箱",
    "sourceChat": "聊天",
    "sourceBrowser": "浏览器",
    "sourceDashboard": "仪表盘",
    "sourcePhone": "电话",
    "sourceVoice": "声音",
    "sourceImport": "进口",
    "sourceSystem": "系统",
    "sourceClaudeCode": "Claude Code",
    "invalidResponse": "无效回复",
    "mcpError": "MCP 错误"
  },
  "danger": {
    "removeLinkTitle": "删除这个链接？",
    "removeLinkAction": "删除链接",
    "disconnectTitle": "断开这个集成？",
    "confirmMoveTitle": "移动这些记忆？"
  },
  "coach": {
    "dismiss": "明白了",
    "dismissAria": "忽略这个提示",
    "sharedTitle": "共享意味着整个团队",
    "sharedBody": "共享记忆是团队中的每个人都可以找到的。个人记忆永远只属于你——你可以为每个记忆选择哪一个，或者默认选择。",
    "autoTitle": "“自动”是什么意思",
    "autoBody": "自动表示你没有为这段记忆选择图层。上方的一行说明了它落在哪里，以及由哪个设置决定——在团队界面的“你的新捕获”下更改你自己的。",
    "lockTitle": "只有作者可以更改共享记忆",
    "lockBody": "一旦记忆被分享，只有分享者或管理员可以编辑或删除它。其他人可以阅读并链接。"
  },
  "activity": {
    "title": "近期活动",
    "intro": "谁改了什么，最新先。作为记录保存——这里内容不能编辑。",
    "loading": "加载中......",
    "empty": "这支队伍还没发生什么事。",
    "loadFailed": "无法加载活动日志。",
    "more": "展示更多",
    "filterAll": "所有人",
    "filterShared": "共享",
    "filterInsights": "见解",
    "filterMembers": "成员",
    "unknownActor": "已移除账户",
    "memoryGone": "内存不再可读",
    "evMemberCreated": "新增一名成员",
    "evMemberRemoved": "移除一名成员",
    "evMemberSuspended": "暂停一名成员",
    "evMemberUnsuspended": "恢复成员",
    "evMemberTokenRotated": "发布了新的登录令牌",
    "evMemberDefaultShareSet": "新捕获的地点变更",
    "evMemberProfileUpdated": "编辑了个人资料",
    "evTeamRenamed": "球队更名",
    "evIntegrationConnected": "连接积分",
    "evIntegrationDisconnected": "断开积分",
    "evIntegrationLayerChanged": "融合记忆落点的变化",
    "evIntegrationMemoriesMoved": "移动了集成中已同步的内存",
    "evShared": "与团队共享一段回忆",
    "evUnshared": "再次让回忆变得私人化",
    "evInsightConfirmed": "证实了一个洞见",
    "evInsightDismissed": "否定了洞察",
    "exportCsv": "导出CSV",
    "exportFailed": "无法导出活动日志。"
  },
  "bulk": {
    "select": "精选",
    "exit": "完成",
    "selectAll": "全部选择",
    "clear": "清场",
    "count": {
      "one": "{n}选",
      "other": "{n}选"
    },
    "shareAction": "与团队共享",
    "privateAction": "设为私密",
    "confirmShareTitle": {
      "one": "和团队分享这个回忆？",
      "other": "与团队分享{n}回忆？"
    },
    "confirmShareBody": "这个团队的每个人都能找到它们。之后你可以让每一个都变得更个人化。",
    "confirmPrivateTitle": {
      "one": "让这段记忆再次变得个人化？",
      "other": "让{n}回忆重新变得个人化？"
    },
    "confirmPrivateBody": "他们会回到你的个人层面。任何人写的都被拒绝，保持共享状态。",
    "working": "处理中：{done} / {total}……",
    "resultMoved": {
      "one": "{n} 已移动",
      "other": "{n} 已移动"
    },
    "resultRefused": {
      "one": "{n}拒绝了——仍然被选中",
      "other": "{n}拒绝了——仍然被选中"
    },
    "resultNone": "什么都没动"
  }
}


// 简体中文界面。经典脚本：公开 t、tPlural、initI18n、applyI18nDom、
// getLocale、localeTag、formatDateUI 等全局函数。

const SB_LOCALE_KEY = 'sb-locale'
const I18N_CATALOGS = { zh: I18N_ZH }
let currentLocale = 'zh'

function resolveI18nPath(messages, path) {
  const parts = String(path).split('.')
  let node = messages
  for (const part of parts) {
    if (node == null || typeof node !== 'object') return undefined
    node = node[part]
  }
  return node
}

function interpolate(raw, params) {
  if (!params) return raw
  return raw.replace(/\{(\w+)\}/g, (_, key) =>
    params[key] != null ? String(params[key]) : `{${key}}`,
  )
}

/** 翻译点分隔键，并替换可选的 `{name}` 占位符。 */
function t(path, params) {
  const node = resolveI18nPath(I18N_CATALOGS.zh, path)
  if (typeof node !== 'string') return path
  return interpolate(node, params)
}

/** 复数辅助函数；中文两个分支使用相同语序，但保留既有键结构。 */
function tPlural(path, n, params) {
  const count = Number(n) || 0
  const key = count === 1 ? `${path}.one` : `${path}.other`
  return t(key, { n: String(count), ...(params || {}) })
}

function getLocale() {
  return currentLocale
}

function localeTag() {
  return 'zh-CN'
}

/** 仅用于界面显示的本地日期；不要用于 LLM 或聊天负载序列化。 */
function formatDateUI(value, options) {
  const d = value instanceof Date ? value : new Date(value)
  if (Number.isNaN(d.getTime())) return ''
  const hasDatePart = options && (options.year || options.month || options.day || options.weekday)
  const hasTimePart = options && (options.hour || options.minute || options.second)
  if (hasTimePart && !hasDatePart) return d.toLocaleTimeString(localeTag(), options)
  return d.toLocaleDateString(localeTag(), options)
}

/** 读取 UTC 日历日期，避免仅日期值因查看者时区而偏移。 */
function formatDateUTC(value, options) {
  const d = value instanceof Date ? value : new Date(value)
  if (Number.isNaN(d.getTime())) return ''
  return new Intl.DateTimeFormat(localeTag(), { ...options, timeZone: 'UTC' }).format(d)
}

function formatNumberUI(n) {
  return Number(n).toLocaleString(localeTag())
}

function initI18n() {
  currentLocale = 'zh'
  try {
    localStorage.setItem(SB_LOCALE_KEY, currentLocale)
  } catch (_) {
    /* 忽略不可用的存储 */
  }
  if (typeof document !== 'undefined' && document.documentElement) {
    document.documentElement.lang = 'zh-CN'
  }
  return currentLocale
}

// 为旧调用点保留兼容入口；单语言版本始终使用中文。
function setLocale() {
  initI18n()
}

function applyLocale() {
  document.querySelectorAll('#locale-toggle [data-locale-val]').forEach((button) =>
    button.classList.toggle('active', button.dataset.localeVal === 'zh'),
  )
}

/**
 * 将 data-i18n、data-i18n-html、data-i18n-attr 应用于 root 下的元素。
 * data-i18n 设置 textContent；data-i18n-html 设置可信语言包 HTML；
 * data-i18n-attr 可设置 placeholder、title 或 aria-label。
 */
function applyI18nDom(root) {
  const scope = root || document
  if (!scope.querySelectorAll) return
  scope.querySelectorAll('[data-i18n]').forEach((el) => {
    const key = el.getAttribute('data-i18n')
    if (!key) return
    const attrList = el.getAttribute('data-i18n-attr')
    if (attrList) {
      const text = t(key)
      attrList.split('|').forEach((attr) => {
        const name = attr.trim()
        if (name) el.setAttribute(name, text)
      })
      return
    }
    if (el.hasAttribute('data-i18n-html')) {
      el.innerHTML = t(key)
    } else {
      el.textContent = t(key)
    }
  })
}
